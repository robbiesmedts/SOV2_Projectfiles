Imports System.Net
Imports System.Net.Sockets

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ip_old(4) As Byte
        Dim ip_new(4) As Byte
        Dim bc(4) As Byte
        Dim data(30) As Byte

        ' ***********************************************
        If TextBox1.Text = "" Then
            ip_old(0) = 0
        Else
            ip_old(0) = CType(TextBox1.Text, Decimal)
        End If

        If TextBox2.Text = "" Then
            ip_old(1) = 0
        Else
            ip_old(1) = CType(TextBox2.Text, Decimal)
        End If

        If TextBox3.Text = "" Then
            ip_old(2) = 0
        Else
            ip_old(2) = CType(TextBox3.Text, Decimal)
        End If

        If TextBox4.Text = "" Then
            ip_old(3) = 0
        Else
            ip_old(3) = CType(TextBox4.Text, Decimal)
        End If

        ' ***********************************************
        If TextBox5.Text = "" Then
            ip_new(0) = 0
        Else
            ip_new(0) = CType(TextBox5.Text, Decimal)
        End If

        If TextBox6.Text = "" Then
            ip_new(1) = 0
        Else
            ip_new(1) = CType(TextBox6.Text, Decimal)
        End If

        If TextBox7.Text = "" Then
            ip_new(2) = 0
        Else
            ip_new(2) = CType(TextBox7.Text, Decimal)
        End If

        If TextBox8.Text = "" Then
            ip_new(3) = 0
        Else
            ip_new(3) = CType(TextBox8.Text, Decimal)
        End If

        ' ***********************************************
        If TextBox9.Text = "" Then
            bc(0) = 0
        Else
            bc(0) = CType(TextBox9.Text, Decimal)
        End If

        If TextBox10.Text = "" Then
            bc(1) = 0
        Else
            bc(1) = CType(TextBox10.Text, Decimal)
        End If

        If TextBox11.Text = "" Then
            bc(2) = 0
        Else
            bc(2) = CType(TextBox11.Text, Decimal)
        End If

        If TextBox12.Text = "" Then
            bc(3) = 0
        Else
            bc(3) = CType(TextBox12.Text, Decimal)
        End If

        ' Erstellt eine Instanz zur Kommunikation per UDP von einem beliebigen 
        ' lokalen Port
        Dim client As UdpClient = New UdpClient(0)
        ' Port 9 ist laut IANA discard, daher kann er ohne Probleme 
        ' verwendet werden
        Dim receiver As IPEndPoint = New IPEndPoint(IPAddress.Broadcast, 7600)

        For i As Integer = 0 To 30
            data(i) = &HFF
        Next

        data(0) = Asc("C")
        data(1) = Asc("M")
        data(2) = Asc("D")
        data(3) = Asc(" ")
        data(4) = Asc("I")
        data(5) = Asc("P")
        data(6) = Asc(" ")

        data(7) = ip_new(0)
        data(8) = ip_new(1)
        data(9) = ip_new(2)
        data(10) = ip_new(3)

        data(11) = ip_old(0)
        data(12) = ip_old(1)
        data(13) = ip_old(2)
        data(14) = ip_old(3)

        data(15) = bc(0)
        data(16) = bc(1)
        data(17) = bc(2)
        data(18) = bc(3)


        ' Senden des Paketes
        client.Send(data, 30, receiver)

    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox5_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub


    Private Sub TextBox6_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox7_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox8_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox9_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub


    Private Sub TextBox10_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox11_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox12_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        Select Case Asc(e.KeyChar)
            Case 48 To 57, 8
                ' Zahlen, Backspace

            Case Else
                ' alle anderen Eingaben unterdr�cken
                e.Handled = True
        End Select
    End Sub
End Class
