/*----------------------------------------------------------------------------
 Copyright:      Radig Ulrich  mailto: mail@ulrichradig.de
 Author:         Radig Ulrich
 Remarks:
 known Problems: none
 Version:        24.10.2007
 Description:    Timer Routinen

 Dieses Programm ist freie Software. Sie k�nnen es unter den Bedingungen der 
 GNU General Public License, wie von der Free Software Foundation ver�ffentlicht, 
 weitergeben und/oder modifizieren, entweder gem�� Version 2 der Lizenz oder 
 (nach Ihrer Option) jeder sp�teren Version. 

 Die Ver�ffentlichung dieses Programms erfolgt in der Hoffnung, 
 da� es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 sogar ohne die implizite Garantie der MARKTREIFE oder der VERWENDBARKEIT 
 F�R EINEN BESTIMMTEN ZWECK. Details finden Sie in der GNU General Public License. 

 Sie sollten eine Kopie der GNU General Public License zusammen mit diesem 
 Programm erhalten haben. 
 Falls nicht, schreiben Sie an die Free Software Foundation, 
 Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA. 
------------------------------------------------------------------------------*/
#include "timer.h"

volatile unsigned long time = 0;
//volatile unsigned long next_reset = 0;

//----------------------------------------------------------------------------
//Diese Routine startet und inizialisiert den Timer
void timer_init (void)
{
	TCCR1B |= (1<<WGM12) | (1<<CS10 | 0<<CS11 | 1<<CS12);
	TCNT1 = 0;
	OCR1A = (F_CPU / 1024) - 1;
	TIMSK1 |= (1 << OCIE1A);
	//next_reset = time + RESET_TIME;
	return;
};

//----------------------------------------------------------------------------
//Timer Interrupt
ISR (TIMER1_COMPA_vect)
{
	//tick 1 second
	time++;
	
	//if(next_reset == time)
	//{
		//Ethernet Interrupt deaktivieren
		//ETH_INT_DISABLE;
		//void artnet_store_dmx_data (void);
		
		//WDTCSR = (1<<WDCE) | (1<<WDE);
		//WDTCSR = (1<<WDCE) | (1<<WDE) | (1<<WDP0) | (1<<WDP1) | (1<<WDP2);
		//while(1);
	//}	
	
    eth.timer = 1;
	artnet_tick();
}
