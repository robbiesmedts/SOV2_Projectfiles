/*----------------------------------------------------------------------------
 Copyright:      Radig Ulrich  mailto: mail@ulrichradig.de
 Author:         Radig Ulrich
 Remarks:        
 known Problems: none
 Version:        24.10.2007
 Description:    Webserver uvm.

 Dieses Programm ist freie Software. Sie k�nnen es unter den Bedingungen der 
 GNU General Public License, wie von der Free Software Foundation ver�ffentlicht, 
 weitergeben und/oder modifizieren, entweder gem�� Version 2 der Lizenz oder 
 (nach Ihrer Option) jeder sp�teren Version. 

 Die Ver�ffentlichung dieses Programms erfolgt in der Hoffnung, 
 da� es Ihnen von Nutzen sein wird, aber OHNE IRGENDEINE GARANTIE, 
 sogar ohne die implizite Garantie der MARKTREIFE oder der VERWENDBARKEIT 
 F�R EINEN BESTIMMTEN ZWECK. Details finden Sie in der GNU General Public License. 

 Sie sollten eine Kopie der GNU General Public License zusammen mit diesem 
 Programm erhalten haben. 
 Falls nicht, schreiben Sie an die Free Software Foundation, 
 Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA. 
----------------------------------------------------------------------------*/

#include <avr/io.h>
#include "config.h"
#include "usart.h"
#include "networkcard/enc28j60.h"
#include "stack.h"
#include "timer.h"
#include "artnet.h"
#include "udp_cmd.h"

//----------------------------------------------------------------------------
//Hier startet das Hauptprogramm
int main(void)
{  	
	unsigned long time_old = 5;
	unsigned long a;
	_delay_ms(500);
	    
	//EEPROM l�schen?
	DDRC |= (1<<PC4); //PD7 Output
	PORTC |= (1<<PC5); //interne pull up on
	PORTC &= ~(1<<PC4); // Port D7 auf low
	_delay_ms(100);
	//Abfrage ob Jumper PD7 und PD6 gesetzt ist
	if(!(PINC&(1<<PC5)))
	{
		//EEPROM wird gel�scht!
		for(unsigned int tmp = 0;tmp<2048;tmp++)
		{
			eeprom_busy_wait ();
			eeprom_write_byte((unsigned char *)tmp,0xFF);
		}
		//Ende!!
		while(1);
	}
	DDRC &= ~(1<<PC4);				
    usart_init(BAUDRATE); // setup the UART

	//Applikationen starten
	stack_init();
	udp_cmd_init();
	artnet_init();
	
	//Ethernetcard Interrupt enable
	ETH_INT_ENABLE;
	
	//Globale Interrupts einschalten
	sei(); 
	
	//LED blink test
	enc28j60_led_blink (1);
	for(a=0;a<5000000;a++) asm("nop");
	enc28j60_led_blink (0);

    //usart_write("\r\nIP   %1i.%1i.%1i.%1i\r\n", myip[0]     , myip[1]     , myip[2]     , myip[3]);
    //usart_write("MASK %1i.%1i.%1i.%1i\r\n", netmask[0]  , netmask[1]  , netmask[2]  , netmask[3]);
    //usart_write("GW   %1i.%1i.%1i.%1i\r\n", router_ip[0], router_ip[1], router_ip[2], router_ip[3]);
    	
	while(1)
	{
	    eth_get_data();
		artnet_main();  
		
		//Ethernet OK??
		if(time > time_old)
		{
			//Toggel LED1 on PORTB0
			if(eth.no_reset)
			{
				eth.no_reset = 0;
			}
			else
			{
				ETH_INT_DISABLE;
				enc_init();
				enc28j60_led_blink (0);
				ETH_INT_ENABLE;
			}
			time_old = time+5;
		}                    
    }		
return(0);
}

