﻿Imports System.Net
Imports System.Net.Sockets
Imports System.Threading

Public Class Form1

    Dim udpClient As UdpClient
    Dim clientThread As Thread = New Thread(New ThreadStart(AddressOf ThreadPacket))
    Dim datei_load As String
    Dim get_udp_data As Byte = 0
    Dim udp_data_get_back(600) As Byte
    Dim temp As Integer = 0
    Dim timeout As Integer = 0
    Dim target_ip(4) As Byte
    Dim data_bytes(600) As Byte
    Dim error_sub As Byte = 0

    Const PAGESIZE As Integer = 137 'PageSize ATmega328 = 128Bytes + 9Bytes Protokoll

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim FileLänge As Long
        Dim getByte As New String(" ", 1)
        Dim parser_state As Byte
        Dim hex_buffer As String
        Dim hex_cnt As Byte
        Dim hex_size As Byte
        Dim hex_adr(2) As Byte
        Dim hex_data_cnt As Integer
        Dim flash_cnt As Integer
        Dim flash_page_flag As Byte

        'Variablen für % Anzeige
        Dim flash_status As Byte
        Dim flash_status_div As Integer

        'Wurde eine Datei ausgewählt
        If TextBoxLoad.Text = "" Then
            InfoBox.Text = ("Es wurde keine Datei ausgewählt! (ENDE)")
            Return
        End If

        'Datei öffnen
        FileOpen(1, datei_load, OpenMode.Binary)
        'Filelänge einlesen
        FileLänge = FileLen(datei_load)
        flash_status_div = FileLänge / 100
        If FileLänge = 0 Then
            InfoBox.Text = ("Datei hat keinen Inhalt! (Ende)")
            GoTo EndFlash
        End If

        'Auflösung der Eingegebenen IP
        If TextBox1.Text = "" Then 'IP BOX enthält nichts
            TextBox1.Text = "0"
        End If

        If TextBox2.Text = "" Then 'IP BOX enthält nichts
            TextBox2.Text = "0"
        End If

        If TextBox3.Text = "" Then 'IP BOX enthält nichts
            TextBox3.Text = "0"
        End If

        If TextBox4.Text = "" Then 'IP BOX enthält nichts
            TextBox4.Text = "0"
        End If

        target_ip(0) = CType(TextBox1.Text, Decimal)
        target_ip(1) = CType(TextBox2.Text, Decimal)
        target_ip(2) = CType(TextBox3.Text, Decimal)
        target_ip(3) = CType(TextBox4.Text, Decimal)


        'Datenspeicher löschen
        For i As Integer = 0 To PAGESIZE
            data_bytes(i) = &HFF
        Next

        ' Erstellt eine Instanz zur Kommunikation per UDP von einem beliebigen 
        ' lokalen Port
        Dim client As UdpClient = New UdpClient(0)
        Dim receiver As IPEndPoint = New IPEndPoint(IPAddress.Broadcast, 7602)

        'Daten für Bootloader lock
        data_bytes(0) = target_ip(0)
        data_bytes(1) = target_ip(1)
        data_bytes(2) = target_ip(2)
        data_bytes(3) = target_ip(3)

        data_bytes(4) = Asc("H") 'H == Echo OK Bootloader lock

        InfoBox.Text = ("Warte auf Antwort! (Abbruch nach 10s)")
        InfoBox.Update()
        timeout = 0
        get_udp_data = 0
        Do While System.Text.Encoding.ASCII.GetString(udp_data_get_back) <> "OK"
            While get_udp_data = 0
                ' Senden des Paketes
                'Warte auf Bestätigung 'OK'
                client.Send(data_bytes, 5, receiver)
                Thread.Sleep(500)
                timeout = timeout + 1
                If (timeout > 20) Then
                    InfoBox.Text = ("Keine Antwort vom Zielsystem! (ENDE)")
                    GoTo EndFlash
                End If
            End While
            get_udp_data = 0
        Loop
        InfoBox.Text = ("Zielsystem gefunden!")
        InfoBox.Update()


        '##############################################################################
        'HEX File Parser
        parser_state = 0
        hex_cnt = 0
        flash_cnt = 0
        hex_data_cnt = 0
        hex_buffer = ""
        flash_page_flag = 0


        While FileLänge <> 0
            FileGet(1, getByte)
            FileLänge = FileLänge - 1


            flash_status = 100 - (FileLänge / flash_status_div)
            InfoBox.Text = ("Programm " & flash_status & "%")
            InfoBox.Update()

            Select Case parser_state

                Case 0
                    'Warte auf Zeilen-Startzeichen
                    If getByte = ":" Then
                        parser_state = 1
                    End If

                Case 1
                    'Parse Datengröße
                    hex_buffer = hex_buffer & getByte
                    hex_cnt = hex_cnt + 1
                    If hex_cnt = 2 Then
                        hex_cnt = 0
                        parser_state = 2
                        hex_size = Convert.ToByte(hex_buffer.Substring(0, 2), 16)
                        hex_buffer = ""
                    End If

                Case 2
                    'Parse Zieladresse
                    hex_buffer = hex_buffer & getByte
                    hex_cnt = hex_cnt + 1
                    If hex_cnt = 4 Then
                        hex_cnt = 0
                        parser_state = 3
                        hex_adr(1) = Convert.ToByte(hex_buffer.Substring(0, 2), 16)
                        hex_adr(0) = Convert.ToByte(hex_buffer.Substring(2, 2), 16)
                        InfoBox.Update()
                        hex_buffer = ""
                        If flash_page_flag = 0 Then
                            'Page Adresse
                            data_bytes(5) = hex_adr(0)
                            data_bytes(6) = hex_adr(1)
                            data_bytes(7) = 0
                            data_bytes(8) = 0
                            flash_page_flag = 1
                        End If
                    End If

                Case 3
                    'Parse Zeilentyp
                    hex_buffer = hex_buffer & getByte
                    hex_cnt = hex_cnt + 1
                    If hex_cnt = 2 Then
                        hex_cnt = 0
                        If Convert.ToByte(hex_buffer.Substring(0, 2), 16) = 0 Then
                            parser_state = 4
                        Else
                            parser_state = 5
                        End If
                        hex_buffer = ""
                    End If

                Case 4
                    'Parse Data
                    hex_buffer = hex_buffer & getByte
                    hex_cnt = hex_cnt + 1
                    If hex_cnt = 2 Then
                        hex_cnt = 0
                        data_bytes(9 + flash_cnt) = Convert.ToByte(hex_buffer.Substring(0, 2), 16)
                        flash_cnt = flash_cnt + 1
                        hex_buffer = ""
                        hex_data_cnt = hex_data_cnt + 1
                        If hex_data_cnt = hex_size Then
                            hex_data_cnt = 0
                            parser_state = 5
                        End If
                        'Puffer voll -> schreibe Page
                        If (flash_cnt + 9) = PAGESIZE Then
                            'Programmieren des Speichers
                            programm_flash()
                            If error_sub = 1 Then
                                MsgBox("Fehler")
                                GoTo EndFlash
                            End If
                            flash_cnt = 0
                            flash_page_flag = 0
                            'Datenspeicher löschen
                            For i As Integer = 0 To PAGESIZE
                                data_bytes(i) = &HFF
                            Next
                        End If
                    End If

                Case 5
                    'Parse Checksumme wird noch nicht überprüft
                    parser_state = 0
            End Select
        End While

        'Den Rest Programmieren
        If flash_page_flag = 1 Then
            'Programmieren des Speichers
            programm_flash()
            If error_sub = 1 Then
                MsgBox("Fehler")
                GoTo EndFlash
            End If
            flash_cnt = 0
            flash_page_flag = 0
        End If

        'Bootloader verlassen (E = EXIT)
        'IP ins UDP Datenpacket eintragen
        data_bytes(0) = target_ip(0)
        data_bytes(1) = target_ip(1)
        data_bytes(2) = target_ip(2)
        data_bytes(3) = target_ip(3)

        data_bytes(4) = Asc("E")
        client.Send(data_bytes, 5, receiver)
        MsgBox("Update fertig")


EndFlash:
        'Datei schließen
        FileClose(1)

    End Sub

    Private Function StringToByteArray(ByVal hex As String) As Byte()
        Dim NumberChars As Integer = hex.Length
        Dim bytes(NumberChars \ 2 - 1) As Byte
        For i As Integer = 0 To NumberChars - 1 Step 2
            bytes(i \ 2) = Convert.ToByte(hex.Substring(i, 2), 16)
        Next
        Return bytes
    End Function

    Private Sub programm_flash()
        ' Erstellt eine Instanz zur Kommunikation per UDP von einem beliebigen 
        ' lokalen Port
        Dim client As UdpClient = New UdpClient(0)
        Dim receiver As IPEndPoint = New IPEndPoint(IPAddress.Broadcast, 7602)

        timeout = 0
        get_udp_data = 0

        'IP ins UDP Datenpacket eintragen
        data_bytes(0) = target_ip(0)
        data_bytes(1) = target_ip(1)
        data_bytes(2) = target_ip(2)
        data_bytes(3) = target_ip(3)

        data_bytes(4) = Asc("P") 'P == Programm

        While get_udp_data = 0
            'Senden der Flash Daten
            'Warte auf Bestätigung 'OK'
            client.Send(data_bytes, PAGESIZE, receiver)
            Thread.Sleep(250)
            timeout = timeout + 1
            If (timeout > 5) Then
                InfoBox.Text = ("Keine Antwort vom Zielsystem!")
                InfoBox.Update()
                error_sub = 1
                Return
            End If
        End While

        timeout = 0
        get_udp_data = 0

        'Verify haben die Empfangenen Daten die richtige Länge?
        temp = UBound(udp_data_get_back) + 1
        If (temp <> PAGESIZE) Then
            InfoBox.Text = ("Fehler in der Übertragungslänge!")
            InfoBox.Update()
            error_sub = 1
            Return
        Else
            'Verify haben die Daten den richtigen Inhalt?
            For i As Integer = 0 To PAGESIZE - 1
                If data_bytes(i) <> udp_data_get_back(i) Then
                    InfoBox.Text = ("Fehler in den Übertragungsdaten!")
                    InfoBox.Update()
                    error_sub = 1
                    Return
                End If
            Next
        End If


    End Sub

    Public Sub ThreadPacket()
        While True
            Dim message As Byte() = udpClient.Receive(New IPEndPoint(IPAddress.Parse("127.0.0.1"), 7603))
            get_udp_data = 1
            udp_data_get_back = message
        End While
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        udpClient = New UdpClient(7603)
        clientThread.Start()

    End Sub

    Private Sub Form_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        clientThread.Abort()
        udpClient.Close()
        Me.Dispose()
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        Dim tmp As Integer
        If TextBox1.Text = "" Then
            tmp = 0
        Else
            tmp = CType(TextBox1.Text, Decimal)
        End If

        Select Case Asc(e.KeyChar)
            Case 48 To 57
                If tmp > 25 Then
                    e.Handled = True
                End If
                If tmp = 25 And Asc(e.KeyChar) > 53 Then
                    e.Handled = True
                End If
                ' Zahlen
            Case 8
                ' Backspace
            Case Else
                ' alle anderen Eingaben unterdrücken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        Dim tmp As Integer
        If TextBox2.Text = "" Then
            tmp = 0
        Else
            tmp = CType(TextBox2.Text, Decimal)
        End If

        Select Case Asc(e.KeyChar)
            Case 48 To 57
                If tmp > 25 Then
                    e.Handled = True
                End If
                If tmp = 25 And Asc(e.KeyChar) > 53 Then
                    e.Handled = True
                End If
                ' Zahlen
            Case 8
                ' Backspace
            Case Else
                ' alle anderen Eingaben unterdrücken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox3_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox3.KeyPress
        Dim tmp As Integer
        If TextBox3.Text = "" Then
            tmp = 0
        Else
            tmp = CType(TextBox3.Text, Decimal)
        End If

        Select Case Asc(e.KeyChar)
            Case 48 To 57
                If tmp > 25 Then
                    e.Handled = True
                End If
                If tmp = 25 And Asc(e.KeyChar) > 53 Then
                    e.Handled = True
                End If
                ' Zahlen
            Case 8
                ' Backspace
            Case Else
                ' alle anderen Eingaben unterdrücken
                e.Handled = True
        End Select
    End Sub

    Private Sub TextBox4_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox4.KeyPress
        Dim tmp As Integer
        If TextBox4.Text = "" Then
            tmp = 0
        Else
            tmp = CType(TextBox4.Text, Decimal)
        End If

        Select Case Asc(e.KeyChar)
            Case 48 To 57
                If tmp > 25 Then
                    e.Handled = True
                End If
                If tmp = 25 And Asc(e.KeyChar) > 53 Then
                    e.Handled = True
                End If
                ' Zahlen
            Case 8
                ' Backspace
            Case Else
                ' alle anderen Eingaben unterdrücken
                e.Handled = True
        End Select
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' Displays an OpenFileDialog so the user can select a Cursor.
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.Filter = "Flash Files|*.hex"
        openFileDialog1.Title = "Select a Flash File"

        openFileDialog1.ShowDialog()
        datei_load = openFileDialog1.FileName()
        TextBoxLoad.Text = datei_load

        ' Show the Dialog.
        ' If the user clicked OK in the dialog and 
        ' a .CUR file was selected, open it.
        'If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
        ' Assign the cursor in the Stream to the Form's Cursor property.
        'Me.Cursor = New Cursor(openFileDialog1.OpenFile())
        'End If
    End Sub
End Class
