/*
 * LED_blink.c
 *
 * Created: 01.05.2013 16:44:46
 *  Author: Ulrich
 */ 


#include <avr/io.h>
#include <avr/interrupt.h>

#define F_CPU 20000000UL 
//############################################################################
ISR (TIMER2_COMPA_vect)
{
	static char tmp =0;
	
	tmp++;
	if(tmp > 200)
	{
		tmp = 0;
		PORTC ^= (1<<PC4);
	}
}

//############################################################################
int main(void)
{
	//Output Pin for LED
	DDRC |= (1<<PC4);
	PORTC |= (1<<PC4);
	
	//Timer2 Life LED
	TCCR2A |= (1<<WGM21);
	TCCR2B |= (1<<CS22|1<<CS21|1<<CS20);
	TIMSK2 |= (1<<OCIE2A);
	OCR2A = F_CPU/1024/1000 - 1; //Tick Time
	
	sei();
	
	while(1)
	{
	}
}